#################
Django Highcharts
#################

Generate charts in you Django application using Highcharts helpers.

This library is mostly based on `django-chartjs <https://github.com/novapost/django-chartjs/>`_,
by Rémy Hubscher.

Please don't try to use it yet, it's really not ready.

* `Documentation is on RTFD <http://django-highcharts.readthedocs.org/en/latest/>`_
* `Source code is on Github <https://github.com/novapost/django-highcharts>`_
