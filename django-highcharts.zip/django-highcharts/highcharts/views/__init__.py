from highcharts.views.bar import HighChartsBarView  # noqa
from highcharts.views.line import HighChartsLineView  # noqa
from highcharts.views.area import HighChartsAreaView  # noqa
